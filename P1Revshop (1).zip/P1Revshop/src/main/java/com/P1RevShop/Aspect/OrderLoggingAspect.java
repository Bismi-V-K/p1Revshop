package com.P1RevShop.Aspect;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Order;

@Aspect
@Component
public class OrderLoggingAspect {

    // Before advice: Logs method execution before saveOrderItems
    @Before("execution(* com.P1RevShop.BuyerServiceInterface.OrderServiceInterface.saveOrderItems(..))")
    public void logBeforeSaveOrderItems(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        Order order = (Order) args[0];
        List<Cart> cartItems = (List<Cart>) args[1];
        System.out.println("Before saving order items for Order ID: " + order.getOrderId() + " with " + cartItems.size() + " items.");
    }

    // Around advice: Logs method execution around saveOrderItems
    @Around("execution(* com.P1RevShop.BuyerServiceInterface.OrderServiceInterface.saveOrderItems(..))")
    public Object logAroundSaveOrderItems(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object result = joinPoint.proceed(); // Proceed with the actual method execution
        long endTime = System.currentTimeMillis();
        System.out.println("Execution time of saveOrderItems: " + (endTime - startTime) + " ms");
        return result;
    }

    // After returning advice: Logs the completion of saveOrderItems
    @AfterReturning(pointcut = "execution(* com.P1RevShop.BuyerServiceInterface.OrderServiceInterface.saveOrderItems(..))")
    public void logAfterSaveOrderItems(JoinPoint joinPoint) {
        System.out.println("Successfully saved order items.");
    }
}
