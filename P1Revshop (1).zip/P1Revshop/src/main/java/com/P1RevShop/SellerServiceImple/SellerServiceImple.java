package com.P1RevShop.SellerServiceImple;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.Entity.Seller;
import com.P1RevShop.Repository.SellerRepository;
import com.P1RevShop.SellerServiceInterface.SellerService;
import com.P1RevShop.Utility.PasswordUtil;


@Service
public class SellerServiceImple implements SellerService{
	
	@Autowired
	private SellerRepository sellerRepository;

	@Override
	public void saveSeller(Seller seller) {
		String plainPassword = seller.getPasswordHash();
		seller.setPasswordHash(PasswordUtil.hashPassword(plainPassword));
		sellerRepository.save(seller);
		
	}
	
	@Override
	public	Seller findByEmail(String email) {
		
		return sellerRepository.findByEmail(email); 
		
	}

}
