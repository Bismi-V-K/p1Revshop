package com.P1RevShop.SellerServiceImple;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.Entity.Product;
import com.P1RevShop.Repository.ProductRepository;
import com.P1RevShop.SellerServiceInterface.ProductService;


@Service
public class ProductServiceImple implements ProductService{
	

    @Autowired 
    private ProductRepository productRepository;

    @Override
    public List<Product> getProductsBySellerId(Long sellerId) {
        return productRepository.findBySeller_SellerId(sellerId);
    }

	@Override
	public void saveProduct(Product product) {
		productRepository.save(product);
		
	}

	@Override
	public List<Product> getallProducts() {
	    List<Product> products = productRepository.findAll();
	    for (Product product : products) {
	        System.out.println("Product Name: " + product.getProdName());
	        System.out.println("Price: " + product.getMrp());
	        System.out.println("Description: " + product.getProdDesc());
	    }
	    return products;
	}
	
	@Override
	public List<Product> getProductsByCategoryId(Long category_id) {
	    return productRepository.findByCategory_CategoryId(category_id);
	}

	@Override
	public Product findProductById(Long productId) {
		return productRepository.getById(productId);
	}
	
	@Override
	public boolean deleteProductById(Long productId) {
	    // Assuming you have a repository for Product
	    if (productRepository.existsById(productId)) {
	        productRepository.deleteById(productId);
	        return true; // Successfully deleted
	    }
	    return false; // Product not found
	}


	
	

}
