package com.P1RevShop.SellerServiceImple;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.Entity.Category;
import com.P1RevShop.Repository.CategoryRepository;
import com.P1RevShop.SellerServiceInterface.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService{

	private CategoryRepository categoryRepo;
	
	@Autowired
    public CategoryServiceImpl(CategoryRepository categoryRepo) {
        this.categoryRepo = categoryRepo;
    }
	
	public List<Category> getAllCategory(){
		return categoryRepo.findAll();
	}

	@Override
	public Category getCategoryById(Long id) {
		return categoryRepo.findById(id).orElse(null);
	}
	
	
}
