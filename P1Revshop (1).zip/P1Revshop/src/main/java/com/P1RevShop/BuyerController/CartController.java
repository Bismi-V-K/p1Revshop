package com.P1RevShop.BuyerController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.P1RevShop.BuyerServiceImplementation.CartServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Exceptions.InsufficientItemsException;
import com.P1RevShop.SellerServiceInterface.ProductService;

import jakarta.servlet.http.HttpSession;

import java.math.BigDecimal;
import java.util.List;

@Controller
public class CartController {

	 @Autowired
	 private CartServiceInterface cartService;
	 
	 @Autowired
	 private ProductService productService;
	
	 @GetMapping("/cart")
	    public String viewCart(Model model, HttpSession session) {
	        // Assuming the buyer is fetched using the authenticated user's details.
	        // Replace this with how you manage authentication and fetching buyer data.
	        Buyer buyer = (Buyer) session.getAttribute("buyer"); 
	        
	        List<Cart> cartItems = cartService.getCartItemsByBuyer(buyer);
	        model.addAttribute("cartItems", cartItems);
	        session.setAttribute("cartItems", cartItems);

	        return "Cart";  // JSP view name
	   }
	 
	 @GetMapping("/AddToCart/{quantity}")
	 public String addToCart(@PathVariable String quantity,Model model, HttpSession session) {
	     Buyer buyer = (Buyer) session.getAttribute("buyer"); 
	     Product product = (Product) session.getAttribute("product");  // Fetch product from service

//	     if (product == null) {
//	         throw new ProductNotFoundException("Product not found");
//	     }

	     if (product.getNoOfItemsAvailable() < 1) {
	         throw new InsufficientItemsException("The product " + product.getProdName() + " is out of stock.");
	     }

	     Cart cart = new Cart();
	     cart.setProduct(product);
	     cart.setBuyer(buyer);
	     cart.setQuantity(Integer.parseInt(quantity));
	     cartService.addToCart(cart);

	     return "redirect:/product_details_after_login/"+product.getProductId();
	 }

	    
}
