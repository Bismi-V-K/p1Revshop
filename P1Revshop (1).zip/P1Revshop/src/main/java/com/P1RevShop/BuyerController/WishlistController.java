package com.P1RevShop.BuyerController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.P1RevShop.BuyerServiceInterface.WishlistServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Wishlist;
import com.P1RevShop.Repository.BuyerRepository;
import com.P1RevShop.Repository.ProductRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class WishlistController {

	    @Autowired
	    private WishlistServiceInterface wishlistService;

	    @Autowired
	    private ProductRepository productRepository;

	    @Autowired
	    private BuyerRepository buyerRepository;

	    // Method to add a product to the wishlist
	    @PostMapping("/AddToWishlist")
	    public ResponseEntity<String> addToWishlist(@RequestParam("productId") Long productId, @RequestParam("buyerId") Long buyerId) {
	        Product product = productRepository.findById(productId).orElse(null);
	        Buyer buyer = buyerRepository.findById(buyerId).orElse(null);

	        if (product != null && buyer != null) {
	            boolean alreadyInWishlist = wishlistService.isProductInWishlist(buyer, product);
	            if (!alreadyInWishlist) {
	                wishlistService.addToWishlist(buyer, product);
	            }
	            return ResponseEntity.ok("Wishlisted");
	        }
	        return ResponseEntity.badRequest().body("Error adding to wishlist");
	    }
	    
	    @GetMapping("/ViewWishlist")
	    public String viewWishlist(@RequestParam("buyerId") Long buyerId, Model model, HttpSession session) {
	        Buyer buyer = buyerRepository.findById(buyerId).orElse(null);
	        session.setAttribute("buyerId", buyer.getBuyerId());
	        if (buyer != null) {
	       // Ensure session attribute is set
	            List<Wishlist> wishlistItems = wishlistService.getWishlistItems(buyer);

	            model.addAttribute("wishlistItems", wishlistItems);
	        } else {
	            model.addAttribute("error", "Buyer not found");
	        }

	        return "wishlist";  // JSP page name
	    }

	    @GetMapping("/MoveToCart")
	    public String moveToCart(@RequestParam("wishlistId") Long wishlistId, 
	                             @RequestParam("buyerId") Long buyerId) {
	        Wishlist wishlistItem = wishlistService.getWishlistById(wishlistId);
	        if (wishlistItem != null) {
	            Buyer buyer = buyerRepository.findById(buyerId).orElse(null);
	            if (buyer != null) {
	                wishlistService.moveToCart(wishlistItem, buyer); // Move item to cart
	                wishlistService.removeFromWishlist(wishlistItem); // Remove from wishlist
	            }
	        }
	        return "redirect:/ViewWishlist?buyerId=" + buyerId; // Redirect back to the wishlist page
	    }

}
