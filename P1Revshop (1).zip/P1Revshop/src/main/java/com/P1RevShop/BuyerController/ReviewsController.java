package com.P1RevShop.BuyerController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.P1RevShop.BuyerServiceInterface.ReviewServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Reviews;
import com.P1RevShop.SellerServiceInterface.ProductService;

import jakarta.servlet.http.HttpSession;

@Controller
public class ReviewsController {

    @Autowired
    private ReviewServiceInterface reviewService;
    
    @Autowired
    private ProductService productService;
    
    @GetMapping("/submitReview")
    public String addReview(@RequestParam("productId") Long productId, Model model,HttpSession session) {
        // Pass the productId to the review form
        model.addAttribute("productId", productId);
        session.setAttribute("productId", productId);
        return "add_reviews";  // Make sure this view (JSP) uses productId in the form
    }

    
    @PostMapping("/submitReview")
    public String submitReview(
        @ModelAttribute("reviews") String reviewText,   // Capture productId from URL
        HttpSession session, 
        Model model
    ) {
        // Get the buyer from session
        Buyer buyer = (Buyer) session.getAttribute("buyer");

        Long productId=(Long)session.getAttribute("productId");
        // Use the productId to get the product
        Product product = productService.findProductById(productId);

        // Now you can proceed with saving the review
        Reviews review = new Reviews();
        review.setBuyer(buyer);  // Set the buyer
        review.setProduct(product);  // Set the product
        review.setReviews(reviewText);  // Set the review text
        
        // Save the review using your service
        reviewService.saveReview(review);

        // Add any attributes for confirmation or redirection
        model.addAttribute("message", "Thank you so much. Your review has been saved.");


        // Redirect to a confirmation page or return a view name
        return "add_reviews";   // Replace with the actual view name
    }

}
