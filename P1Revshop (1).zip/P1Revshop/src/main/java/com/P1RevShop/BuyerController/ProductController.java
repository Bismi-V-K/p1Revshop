package com.P1RevShop.BuyerController;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.P1RevShop.BuyerServiceImplementation.CartServiceInterface;
import com.P1RevShop.Entity.Category;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Seller;
import com.P1RevShop.SellerServiceInterface.CategoryService;
import com.P1RevShop.SellerServiceInterface.ProductService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class ProductController {
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private CartServiceInterface cartService;

	@GetMapping("/add_new_product")
	public String addNewProduct(HttpSession session) {
	    List<Category> category = categoryService.getAllCategory();
	    
	    
	    
	    session.setAttribute("category", category);  // Store in session
	    return "add_new_product";
	}

	
	@PostMapping("/add_new_product")
	public String addProduct(
	        @RequestParam("prodName") String prodName,
	        @RequestParam("prodDesc") String prodDesc,
	        @RequestParam("mrp") BigDecimal mrp,
	        @RequestParam("discountPrice") BigDecimal discountPrice,
	        @RequestParam("noOfItemsAvailable") int noOfItemsAvailable,
	        @RequestParam("category_id") Long categoryId,
	        @RequestParam("imageFileName") MultipartFile imageFileName,
	        @RequestParam("pickUpAddress") String pickUpAddress,
	        @RequestParam("pickUpCity") String pickUpCity,
	        @RequestParam("pickUpState") String pickUpState,
	        @RequestParam("pickUpCountry") String pickUpCountry,
	        @RequestParam("pickUpPincode") String pickUpPincode,
	        HttpSession session,
	        HttpServletRequest request,
	        Model model) {

	    // Check if the seller is logged in
	    Seller seller = (Seller) session.getAttribute("seller");
	    if (seller == null) {
	        model.addAttribute("error", "Seller not logged in.");
	        return "redirect:/seller_signin";
	    }

	    // Create a new Product instance and set its fields
	    Product product = new Product();
	    product.setProdName(prodName);
	    product.setProdDesc(prodDesc);
	    product.setMrp(mrp);
	    product.setDiscountPrice(discountPrice);
	    product.setNoOfItemsAvailable(noOfItemsAvailable);

	    // Set seller and category for the product
	    Category category = categoryService.getCategoryById(categoryId);
	    product.setCategory(category);
	    product.setSeller(seller);

	    // Set pickup details in the product (make sure your Product class has these fields)
	    product.setPickUpAddress(pickUpAddress);
	    product.setPickUpCity(pickUpCity);
	    product.setPickUpState(pickUpState);
	    product.setPickUpCountry(pickUpCountry);
	    product.setPickUpPincode(pickUpPincode);

	    // Save the image file name and store the file on the server
	    if (!imageFileName.isEmpty()) {
	        try {
	            // Use HttpServletRequest to get the server path
	            String uploadDir = request.getServletContext().getRealPath("/images/");
	            // Ensure the directory exists
	            new File(uploadDir).mkdirs();

	            // Get the original file name and transfer it to the designated directory
	            String fileName = imageFileName.getOriginalFilename();
	            File uploadFile = new File(uploadDir + fileName);

	            imageFileName.transferTo(uploadFile); // Save the file on the server
	            product.setImageFileName(fileName); // Save file name in product
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	            model.addAttribute("error", "Image upload failed.");
	            return "add_new_product"; // Return to form with error
	        }
	    } else {
	        model.addAttribute("error", "Please upload an image.");
	        return "add_new_product"; // Return to form if no image uploaded
	    }

	    // Save the product to the database
	    productService.saveProduct(product);
	    model.addAttribute("message", "Product added successfully!");

	    return "redirect:/add_new_product";
	}
	
	@GetMapping("/update_product")
	public String showUpdateProductForm(@RequestParam("productId") Long productId, Model model, HttpSession session) {
	    // Check if the seller is logged in
	    Seller seller = (Seller) session.getAttribute("seller");
	    if (seller == null) {
	        model.addAttribute("error", "Seller not logged in.");
	        return "redirect:/seller_signin";
	    }

	    // Fetch the product to update
	    Product product = productService.findProductById(productId);
	    if (product == null || !product.getSeller().getSellerId().equals(seller.getSellerId())) {
	        model.addAttribute("error", "Product not found or unauthorized access.");
	        return "error_page";
	    }

	    // Add product details to the model to pre-fill the update form
	    model.addAttribute("product", product);

	    // Fetch categories if required for update form
	    List<Category> categories = categoryService.getAllCategory();
	    model.addAttribute("categories", categories);

	    return "update_product_form"; // JSP to render the update form
	}
	
	@PostMapping("/update_product")
	public String updateProduct(
	        @RequestParam("productId") Long productId,
	        @RequestParam("prodName") String prodName,
	        @RequestParam("prodDesc") String prodDesc,
	        @RequestParam("mrp") BigDecimal mrp,
	        @RequestParam("discountPrice") BigDecimal discountPrice,
	        @RequestParam("noOfItemsAvailable") int noOfItemsAvailable,
	        @RequestParam("category_id") Long categoryId,
	        @RequestParam("imageFileName") MultipartFile imageFileName,
	        Model model) {

	    // Fetch the existing product
	    Product product = productService.findProductById(productId);
	    if (product == null) {
	        model.addAttribute("error", "Product not found.");
	        return "redirect:/error_page"; // Redirect to error page
	    }

	    // Update product details
	    product.setProdName(prodName);
	    product.setProdDesc(prodDesc);
	    product.setMrp(mrp);
	    product.setDiscountPrice(discountPrice);
	    product.setNoOfItemsAvailable(noOfItemsAvailable);

	    // Update category if changed
	    Category category = categoryService.getCategoryById(categoryId);
	    product.setCategory(category);

	    // Update image if a new one is uploaded
	    if (!imageFileName.isEmpty()) {
	        try {
	            String fileName = imageFileName.getOriginalFilename();
	            product.setImageFileName(fileName);
	            String uploadDir = "C:/Users/bismi/OneDrive/Desktop/p1rev/src/main/webapp/images/" + fileName;
	            File uploadFile = new File(uploadDir);
	            uploadFile.getParentFile().mkdirs(); // Create parent directories if not exist
	            imageFileName.transferTo(uploadFile); // Save the file
	        } catch (IOException e) {
	            e.printStackTrace();
	            model.addAttribute("error", "Image upload failed.");
	            return "update_product"; // Return to update product page
	        }
	    }

	    // Save updated product to the database
	    productService.saveProduct(product);
	    model.addAttribute("successMessage", "Product updated successfully!");

	    return "update_product_form"; // Return to the same form with success message
	}
	
	@GetMapping("/delete_product")
	public String deleteProduct(@RequestParam("productId") Long productId, Model model) {
	    // First, delete from the cart
//	    boolean cartDeleted = cartService.deleteCartItemsByProductId(productId);
//	    
//	    if (!cartDeleted) {
//	        model.addAttribute("error", "Error deleting cart items for the product.");
//	        return "redirect:/product_list"; // Redirect if cart deletion fails
//	    }

	    // Now, delete the product from the products table
	    boolean productDeleted = productService.deleteProductById(productId);
	    
	    if (productDeleted) {
	        model.addAttribute("message", "Product deleted successfully!");
	        System.out.println("deleted successfully");
	    } else {
	        model.addAttribute("error", "Error deleting product.");
	    }

	    // Redirect to the product list or another appropriate page
	    return "redirect:/seller_welcome"; // Adjust as needed
	}



}
