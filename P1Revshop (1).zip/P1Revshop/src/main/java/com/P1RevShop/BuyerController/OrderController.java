package com.P1RevShop.BuyerController;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import org.springframework.ui.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.P1RevShop.BuyerServiceImplementation.CartServiceInterface;
import com.P1RevShop.BuyerServiceInterface.BuyerService;
import com.P1RevShop.BuyerServiceInterface.OrderItemServiceInterface;
import com.P1RevShop.BuyerServiceInterface.OrderServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Order;
import com.P1RevShop.Entity.OrderItem;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Seller;
import com.P1RevShop.Repository.ProductRepository;
import com.P1RevShop.Utility.EmailService;

import jakarta.servlet.http.HttpSession;

@Controller
public class OrderController {

	@Autowired
	private BuyerService buyerService;

	@Autowired
	private OrderServiceInterface orderService;

	@Autowired
	private OrderItemServiceInterface orderItemService;

	@Autowired
	private CartServiceInterface cartService;

	@Autowired
	EmailService emailService;

	@Autowired
	ProductRepository productRepository;

	@GetMapping("/checkout")
	public String checkoutPage(HttpSession session, Model model) {
		model.addAttribute("cartItems", session.getAttribute("cartItems"));
		System.out.println(session.getAttribute("cartItems"));
		return "checkout";
	}

	@PostMapping("/checkout")
	public String checkout(Model model, HttpSession session, @ModelAttribute Order order) {
		try {
			Buyer buyer = (Buyer) session.getAttribute("buyer");
			order.setBuyer(buyer);
			System.out.println(buyer.getBuyerName());
			order = setDate(order);
			orderService.saveOrders(order);

			// Get cart items from the session
			List<Cart> cartItems = (List<Cart>) session.getAttribute("cartItems");

			// Save the order items
			for (Cart cartItem : cartItems) {
				Product product = cartItem.getProduct();
				Seller seller = product.getSeller(); // Extract the seller from the product
				System.out.println(seller + "seller");
				// Create OrderItem and set the necessary fields, including seller
				OrderItem orderItem = new OrderItem();
				orderItem.setOrder(order);
				orderItem.setProduct(product);
				orderItem.setQuantity(cartItem.getQuantity());
				orderItem.setSeller(seller); // Set the seller
				orderService.saveOrderItems(order, cartItems); // Save each order item
				// System.out.println(cartItem.getCartId());
			}

			// Clear the cart
			
			System.out.println("welcome from order");

			ResponseEntity.ok("Order placed successfully.");
			
		} catch (Exception e) {
			e.printStackTrace();
			ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Order placement failed.");

		} 
		return "order-success";
	}
	
	@GetMapping("/order_success")
	public String orderSuccess(HttpSession session) {
		Buyer buyer = (Buyer) session.getAttribute("buyer");
		cartService.clearCart(buyer);
		session.removeAttribute("cartItems");
		return "redirect:/buyer_welcome";
	}

	@GetMapping("/view_orders")
	public String viewOrders(HttpSession session, Model model) {
		Long buyerId = (Long) session.getAttribute("buyerId");
		System.out.println(buyerId + "buyer");
		Buyer buyer = buyerService.findByBuyerId(buyerId);

		// Fetch all orders for the buyer
		List<Order> orders = orderService.getOrdersByBuyerId(buyerId);

		// Loop through each order to get associated order items (products)
		for (Order order : orders) {
			List<OrderItem> orderItems = orderItemService.findByOrder(order);
			order.setOrderItems(orderItems); // Setting order items in each order
		}

		// Add orders with their order items and products to the model
		model.addAttribute("orders", orders);
		session.setAttribute("buyerId", buyerId);

		System.out.println("view orders" + orders);
		return "orders"; // Redirect to orders.jsp
	}

	@GetMapping("/placed_orders")
	public String viewPlacedOrders(HttpSession session, Model model) {
		Seller seller = (Seller) session.getAttribute("seller");
		List<OrderItem> items = orderItemService.findBySeller(seller);
		model.addAttribute("orderItems", items);
		System.out.println("Number of order items: " + items.size()); // Debugging line
		model.addAttribute("orderItems", items);
		

		return "placed_orders";
	}

	@PostMapping("/updateOrderStatus")
	public String updateOrderStatus(@RequestParam("orderId") Long orderId, @RequestParam("status") String status,
			HttpSession session,Model model) {
		// Fetch the order by ID
		Order order = orderService.findById(orderId); // You might need to create this method in your orderService
		if (order != null) {
			// Update the order status
			order.setOrder_status(status);
			orderService.saveOrders(order); // Ensure you have a save method to update the order

			// Get buyer's email to send notification
			Buyer buyer = order.getBuyer(); // Assuming you have a getter for buyer
			String buyerEmail = buyer.getBuyerEmail(); // Replace with the correct method to get the email

			// Send an email notification
			String subject = "Order Status Update";
			String body = "Your order (ID: " + orderId + ") status has been updated to: " + status;

			emailService.sendEmail(buyerEmail, body, subject);// Ensure you have this method in your EmailService
			model.addAttribute("updateMessage","Order status updated successfully!");
			// Redirect to the placed orders page or show a success message
			return "redirect:/placed_orders"; // Adjust this to your flow
		}

		// Handle the case when the order is not found (optional)
		return "redirect:/error"; // Or some error page
	}
	public Order setDate(Order order) {
	    Date orderDate = null;
	    Date deliveryDate = null;

	    // Format the dates to dd-MM-yy
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yy");
	    String formattedOrderDate = LocalDate.now().format(formatter);
	    String formattedDeliveryDate = LocalDate.now().plusDays(5).format(formatter);

	    // Create a SimpleDateFormat instance for the specified format
	    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");

	    // Parse the strings to Date objects
	    try {
	        orderDate = sdf.parse(formattedOrderDate);
	        deliveryDate = sdf.parse(formattedDeliveryDate);
	    } catch (java.text.ParseException e) {
	        e.printStackTrace();
	    }

	    // Print the Date objects
	    System.out.println("Order Date: " + orderDate);
	    System.out.println("Delivery Date: " + deliveryDate);
	    order.setDeliveryDate(deliveryDate);
	    order.setOrderDate(orderDate);
	    
	    System.out.println(order.getDeliveryDate()+"delivery date");

	    return order;
	}}