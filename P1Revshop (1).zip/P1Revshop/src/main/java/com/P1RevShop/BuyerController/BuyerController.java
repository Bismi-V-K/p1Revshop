package com.P1RevShop.BuyerController;

import com.P1RevShop.BuyerServiceImplementation.CartServiceInterface;
import com.P1RevShop.BuyerServiceInterface.BuyerService;
import com.P1RevShop.BuyerServiceInterface.WishlistServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Category;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Exceptions.BuyerNotFoundException;
import com.P1RevShop.Exceptions.EmailAlreadyExistsException;
import com.P1RevShop.Exceptions.InvalidOtpException;
import com.P1RevShop.Exceptions.PasswordMismatchException;
import com.P1RevShop.Repository.BuyerRepository;
import com.P1RevShop.Repository.ProductRepository;
import com.P1RevShop.SellerServiceInterface.CategoryService;
import com.P1RevShop.SellerServiceInterface.ProductService;
import com.P1RevShop.Utility.EmailService;
import com.P1RevShop.Utility.PasswordUtil;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@Controller
public class BuyerController {

    @Autowired
    private ProductService productService;

    @Autowired
    private BuyerService buyerService;

    @Autowired
    private EmailService emailService;
    
    @Autowired
    private CategoryService categoryService;

    @Autowired
    private ProductRepository productRepository;
    
    @Autowired
    private BuyerRepository buyerRepository;
    
    @Autowired
    private WishlistServiceInterface wishlistService;
    

    @GetMapping("/BuyerSignup")
    public String showSignupForm() {
        return "buyer_signup"; // JSP page for buyer signup
    }

    @PostMapping("/BuyerSignup")
    public String registerBuyer(@ModelAttribute("buyer") Buyer buyer, HttpSession session, Model model) {
        try {
            // Check if the email already exists
            if (buyerService.findByBuyerEmail(buyer.getBuyerEmail()) != null) {
                throw new EmailAlreadyExistsException("Email already exists.");
            }

            // Continue with OTP generation and registration
            String generatedOTP = EmailService.generateOtp();
            emailService.sendOtpEmail(buyer.getBuyerEmail(), generatedOTP);

            // Hash the password before saving
            String hashedPassword = PasswordUtil.hashPassword(buyer.getPasswordHash());
            buyer.setPasswordHash(hashedPassword);

            session.setAttribute("buyer", buyer);
            session.setAttribute("email", buyer.getBuyerEmail());
            session.setAttribute("buyerName", buyer.getBuyerName());
            session.setAttribute("buyerId", buyer.getBuyerId());
            session.setAttribute("generatedOTP", generatedOTP);
            
            return "buyer_otp"; // JSP page for OTP verification
        } catch (EmailAlreadyExistsException e) {
            model.addAttribute("error", e.getMessage()); // Add the error message to the model
            return "buyer_signup"; // Return to the signup page with error message
        }
    }


    @PostMapping("/buyerverifyotpSignUp")
    public String verifyOtpSignUp(@RequestParam String enteredOtp, HttpSession session, Model model) {
        String email = (String) session.getAttribute("email");
        String generatedOtp = (String) session.getAttribute("generatedOTP");

        // Verify the entered OTP
        if (!emailService.verifyOTP(email, enteredOtp, generatedOtp)) {
            // Throw a custom exception if the OTP is invalid
            throw new InvalidOtpException("Invalid OTP. Please try again.");
        }

        Buyer buyer = (Buyer) session.getAttribute("buyer");
        buyerService.saveBuyer(buyer); // Save buyer with hashed password

        model.addAttribute("message", "Buyer registered successfully!");
        return "redirect:/buyer_welcome"; // Redirect to buyer welcome page
    }

    @GetMapping("/BuyerSignin")
    public String buyerLogin() {
        return "buyer_signin"; // JSP page for buyer login
    }



    @PostMapping("/BuyerSignin")
    public String login(@RequestParam String buyerEmail, @RequestParam String passwordHash, HttpSession session, Model model) {
        Buyer buyer = buyerService.findByBuyerEmail(buyerEmail);
        if (buyer == null) {
            throw new BuyerNotFoundException("Buyer not found with the provided email.");
        }

        // Verify the password entered matches the stored hashed password
        if (!PasswordUtil.verifyPassword(passwordHash, buyer.getPasswordHash())) {
            // Throw PasswordMismatchException if the password is incorrect
            throw new PasswordMismatchException("Incorrect password.");
        }

        // If password is correct, set session attributes and redirect
        session.setAttribute("buyer", buyer);
        session.setAttribute("buyerId", buyer.getBuyerId());
        session.setAttribute("buyerName", buyer.getBuyerName());
        return "redirect:/buyer_welcome";
    }

    @GetMapping("/buyer_welcome")
    public String buyerWelcome(@RequestParam(value = "categoryId", required = false) Long categoryId,Model model, HttpSession session) {
    	List<Category> categories = categoryService.getAllCategory();
        model.addAttribute("categories", categories);
        Buyer buyer = (Buyer) session.getAttribute("buyer");

        session.setAttribute("buyerId", buyer.getBuyerId());
        session.getAttribute("buyerName");
        session.setAttribute("categories", categories);
        List<Product> products;
        if (categoryId != null) {
            products = productService.getProductsByCategoryId(categoryId); // New method to get products by category
        } else {
            products = productService.getallProducts(); // Default to all products if no category is selected
        }
        model.addAttribute("products", products);
        System.out.println("welcome");
        return "buyer_welcome";
//        if (buyer != null) {
//            List<Product> products = productService.getallProducts(); // Fetch all products
//            model.addAttribute("products", products);
//            model.addAttribute("buyerName", buyer.getBuyerName()); // Add buyer's name
//            return "buyer_welcome"; // Redirect to buyer's post-login welcome page
//        } else {
//            return "redirect:/BuyerSignin"; // Redirect to login if not logged in
//        }
    }
    
    @GetMapping("/welcome")
    public String welcomePage(@RequestParam(value = "categoryId", required = false) Long categoryId, Model model) {
        List<Category> categories = categoryService.getAllCategory();
        model.addAttribute("categories", categories);

        List<Product> products;
        if (categoryId != null) {
            products = productService.getProductsByCategoryId(categoryId); // New method to get products by category
        } else {
            products = productService.getallProducts(); // Default to all products if no category is selected
        }
        model.addAttribute("products", products);
        return "welcome-before-login"; // JSP file name
    }
    
    
    @GetMapping("/product_details/{id}")
    public String viewProductDetails(@PathVariable("id") String productId, Model model, HttpSession session) {
    	System.out.println("prod detail");
        Product product = productRepository.getProductByProductId(Long.valueOf(productId));
        model.addAttribute("product", product);
        session.setAttribute("product", product);
        return "product-details-before-login"; // Return the name of the view
    }
    
    @GetMapping("/product_details_after_login/{id}")
    public String viewProductDetailsAfterLogin(@PathVariable("id") String productId, Model model, HttpSession session) {
    	System.out.println("prod detail");
        Product product = productRepository.getProductByProductId(Long.valueOf(productId));
        Long buyerId=(Long)session.getAttribute("buyerId");
        Buyer buyer = buyerRepository.findById(buyerId).orElse(null);
        if (product != null && buyer != null) {
            boolean alreadyInWishlist = wishlistService.isProductInWishlist(buyer, product);
            model.addAttribute("wishlistStatus", alreadyInWishlist ? "wishlisted" : "not_wishlisted");
        } else {
            model.addAttribute("wishlistStatus", "not_wishlisted");
        }
        model.addAttribute("product", product);
        session.setAttribute("product", product);
        return "product_detail"; // Return the name of the view
    }
    
   
    
//    List<Product> products=productService.getallProducts();
//    session.setAttribute("products",products);
//    return "welcome";
    
    
    
 //   @GetMapping("/buyer_forgot_password")
//  public String buyerForgotPassword() {
//      return "buyer_forgot_password"; // JSP page for buyer forgot password
//  }
//
//  @PostMapping("/buyer/forgotpassword")
//  public String forgotPassword(@RequestParam String email, HttpSession session, Model model) {
//      Buyer buyer = buyerService.findByEmail(email); // Check if the buyer exists
//      if (buyer != null) {
//          String generatedOTP = EmailService.generateOtp(); // Generate OTP
//          emailService.sendOtpEmail(email, generatedOTP); // Send the OTP to the user's email
//          session.setAttribute("email", email); // Store email in session
//          session.setAttribute("generatedOTP", generatedOTP); // Store OTP in session
//          return "buyer_verify_otp"; // Redirect to OTP verification page
//      } else {
//          model.addAttribute("error", "Email not found"); // Error if email is not found
//          return "buyer_forgot_password"; // Stay on forgot password page
//      }
//  }
//
//  @PostMapping("/buyer/verifyotp")
//  public String verifyOtp(@RequestParam String enteredOtp, Model model, HttpSession session) {
//      if (enteredOtp.equals(session.getAttribute("generatedOTP"))) {
//          return "buyer_reset_password"; // Redirect to reset password page if OTP is correct
//      } else {
//          model.addAttribute("error", "Invalid OTP"); // Error if OTP is incorrect
//          return "buyer_verify_otp"; // Stay on OTP verification page
//      }
//  }

//  @PostMapping("/buyer/resetpassword")
//  public String resetPassword(HttpSession session, @RequestParam String passwordHash, @RequestParam String confirmPassword, Model model) {
//      String email = (String) session.getAttribute("email");
//      if (!passwordHash.equals(confirmPassword)) {
//          model.addAttribute("error", "Passwords do not match"); // Error if passwords do not match
//          return "buyer_reset_password"; // Stay on reset password page
//      }
//      Buyer buyer = buyerService.findByEmail(email); // Fetch the buyer by email
//      if (buyer != null) {
//          buyer.setPasswordHash(passwordHash); // Set new password
//          buyerService.saveBuyer(buyer); // Save the updated buyer in the database
//          return "redirect:/buyer_signin"; // Redirect to login page after resetting password
//      } else {
//          model.addAttribute("error", "User not found"); // Error if user not found
//          return "buyer_reset_password"; // Stay on reset password page
//      }
//  }

}
