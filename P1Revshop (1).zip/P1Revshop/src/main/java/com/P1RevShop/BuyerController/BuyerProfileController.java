package com.P1RevShop.BuyerController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Repository.BuyerRepository;
import com.P1RevShop.Utility.PasswordUtil;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/buyer")
public class BuyerProfileController {

	@Autowired
	private BuyerRepository buyerRepo;
	
	@GetMapping("/profile")
    public String viewProfile(HttpSession session, Model model) {
        Long buyerId = (Long) session.getAttribute("buyerId"); // Get buyer ID from session
        System.out.println(buyerId);
        if (buyerId != null) {
            Buyer buyer = buyerRepo.findById(buyerId).orElse(null);
            System.out.println("buyer"+buyer.getBuyerEmail());
            if (buyer != null) {
                model.addAttribute("buyer", buyer);
                return "buyer_profile"; // Returns the buyer profile JSP page
            }
            model.addAttribute("error", "Buyer not found!"); // Handle not found
        }
        return "redirect:/buyer_signup"; // Redirect to signup if no buyer ID is found
    }
    
    // Method to edit buyer profile
    @GetMapping("/edit/{buyerId}")
    public String editProfile(@PathVariable Long buyerId, Model model) {
        Buyer buyer = buyerRepo.findById(buyerId).orElse(null);
        if (buyer != null) {
            model.addAttribute("buyer", buyer);
            return "edit_buyer_profile"; // Returns the edit profile JSP page
        }
        model.addAttribute("error", "Buyer not found!"); // Handle not found
        return "redirect:/edit"; // Redirect to profile if buyer not found
    }
    
    // Method to save edited profile
    @PostMapping("/edit")
    public String updateProfile(Buyer buyer, Model model) {
        Buyer existingBuyer = buyerRepo.findById(buyer.getBuyerId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid buyer Id"));
        
        // Check if the buyer has entered a new password
        if (buyer.getPasswordHash() != null && !buyer.getPasswordHash().isEmpty()) {
            // Hash the new password
            String hashedPassword = PasswordUtil.hashPassword(buyer.getPasswordHash());
            buyer.setPasswordHash(hashedPassword);
        } else {
            // Preserve the existing password if no new password is provided
            buyer.setPasswordHash(existingBuyer.getPasswordHash());
        }
        
        // Save the updated buyer information
        buyerRepo.save(buyer);
        model.addAttribute("message", "Profile updated successfully!");
        
        return "buyer_profile"; // Redirect to the profile page
    }


}
