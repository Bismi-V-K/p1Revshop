package com.P1RevShop.Utility;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender; // Autowire JavaMailSender

    public void sendOtpEmail(String to, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Your OTP for Password Reset");
        message.setText("Your OTP is: " + otp); // Set OTP in the email body
        mailSender.send(message); // Send the email
    }
    
    public static String generateOtp() {
        Random random = new Random();
        return String.valueOf(1000 + random.nextInt(9000)); // Generates a number between 1000 and 9999
    }
    
    public boolean verifyOTP(String email, String enteredOTP, String generatedOTP) {
    	
    	return generatedOTP.equals(enteredOTP);
    	
    }
    public void sendEmail(String to, String sender_message,String subject ) {
    	SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(sender_message); // Set OTP in the email body
        mailSender.send(message); // Send the email
    }
}
