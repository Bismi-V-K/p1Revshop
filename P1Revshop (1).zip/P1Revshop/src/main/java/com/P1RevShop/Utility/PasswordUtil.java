package com.P1RevShop.Utility;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordUtil {

    private static final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // Method to hash a password
    public static String hashPassword(String password) {
        return passwordEncoder.encode(password);
    }

    // Method to verify a password
    public static boolean verifyPassword(String rawPassword, String hashedPassword) {
        return passwordEncoder.matches(rawPassword, hashedPassword);
    }
}
//
//public class UserService {
//
//    public void registerUser(String username, String rawPassword) {
//        // Hash the password before storing it
//        String hashedPassword = PasswordUtil.hashPassword(rawPassword);
//        
//        // Store the username and hashed password in the database
//        // Example: saveUserToDatabase(username, hashedPassword);
//    }
//
//    public boolean loginUser(String username, String rawPassword) {
//        // Retrieve the hashed password from the database
//        // Example: String hashedPassword = getHashedPasswordFromDatabase(username);
//
//        // Check if the raw password matches the hashed password
//        return PasswordUtil.verifyPassword(rawPassword, hashedPassword);
//    }
//}

