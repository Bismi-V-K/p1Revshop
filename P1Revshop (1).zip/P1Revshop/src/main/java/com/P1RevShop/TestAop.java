package com.P1RevShop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.P1RevShop.BuyerServiceInterface.OrderServiceInterface;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Order;

import java.util.ArrayList;
import java.util.List;

@Component
public class TestAop implements CommandLineRunner {

    @Autowired
    private OrderServiceInterface orderService;

    @Override
    public void run(String... args) throws Exception {
        Order order = new Order();
        order.setOrderId(1L); // Set up the order ID or other properties as needed

        List<Cart> cartItems = new ArrayList<>();
        // Populate cartItems with Cart objects (with products) for testing

        orderService.saveOrderItems(order, cartItems); // Call the method to test AOP
    }
}
