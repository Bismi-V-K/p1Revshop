package com.P1RevShop.SellerController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Seller;
import com.P1RevShop.Repository.BuyerRepository;
import com.P1RevShop.Repository.SellerRepository;
import com.P1RevShop.Utility.PasswordUtil;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/seller")
public class SellerProfileController {

	@Autowired
	private SellerRepository sellerrepo;
	
	@GetMapping("/profile")
    public String viewProfile(HttpSession session, Model model) {
        Long sellerId = (Long) session.getAttribute("sellerId"); // Get buyer ID from session
        System.out.println(sellerId);
        if (sellerId != null) {
            Seller seller = sellerrepo.findById(sellerId).orElse(null);
            System.out.println("seller"+seller.getEmail());
            if (seller != null) {
                model.addAttribute("seller", seller);
                return "seller_profile"; // Returns the buyer profile JSP page
            }
            model.addAttribute("error", "seller not found!"); // Handle not found
        }
        return "redirect:/seller_signup"; // Redirect to signup if no buyer ID is found
    }
    
    // Method to edit buyer profile
    @GetMapping("/edit/{sellerId}")
    public String editProfile(@PathVariable Long sellerId, Model model) {
        Seller seller = sellerrepo.findById(sellerId).orElse(null);
        if (seller != null) {
            model.addAttribute("seller", seller);
            return "edit_seller_profile"; // Returns the edit profile JSP page
        }
        model.addAttribute("error", "Seller not found!"); // Handle not found
        return "redirect:/edit"; // Redirect to profile if buyer not found
    }
    
    // Method to save edited profile
    @PostMapping("/edit")
    public String updateProfile(Seller seller, Model model) {
        Seller existingSeller = sellerrepo.findById(seller.getSellerId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid seller Id"));
        
        // Check if the buyer has entered a new password
        if (seller.getPasswordHash() != null && !seller.getPasswordHash().isEmpty()) {
            // Hash the new password
            String hashedPassword = PasswordUtil.hashPassword(seller.getPasswordHash());
            seller.setPasswordHash(hashedPassword);
        } else {
            // Preserve the existing password if no new password is provided
            seller.setPasswordHash(existingSeller.getPasswordHash());
        }
        
        // Save the updated buyer information
        sellerrepo.save(seller);
        model.addAttribute("message", "Profile updated successfully!");
        
        return "seller_profile"; // Redirect to the profile page
    }


}
