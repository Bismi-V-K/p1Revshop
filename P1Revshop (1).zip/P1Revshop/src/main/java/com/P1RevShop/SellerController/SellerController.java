package com.P1RevShop.SellerController;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;

//controller for seller signup, seller signin and welcome page


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.P1RevShop.Entity.Category;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Seller;
import com.P1RevShop.Exceptions.BuyerNotFoundException;
import com.P1RevShop.Exceptions.EmailAlreadyExistsException;
import com.P1RevShop.Exceptions.InvalidOtpException;
import com.P1RevShop.Exceptions.InvalidOtpExceptionSeller;
import com.P1RevShop.Exceptions.PasswordMismatchException;
import com.P1RevShop.Exceptions.PasswordMismatchExceptionSeller;
import com.P1RevShop.Exceptions.SellerNotFoundException;
import com.P1RevShop.Repository.ProductRepository;
import com.P1RevShop.SellerServiceInterface.CategoryService;

import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Seller;

import com.P1RevShop.SellerServiceInterface.ProductService;
import com.P1RevShop.SellerServiceInterface.SellerService;
import com.P1RevShop.Utility.EmailService;
import com.P1RevShop.Utility.PasswordUtil;

import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class SellerController {

	@Autowired
	private SellerService sellerService;

	@Autowired
	private EmailService emailService;
	
	@Autowired
	private ProductService productService;

	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private ProductRepository productRepository;
	

	@GetMapping("/SellerSignup")
	public String showSignupForm() {

		return "seller_signup";
	}

	@PostMapping("/SellerSignup")
	public String registerSeller(@ModelAttribute("seller") Seller seller,HttpSession session, Model model) {
		try {
			if(sellerService.findByEmail(seller.getEmail())!=null) {
				throw new EmailAlreadyExistsException("Email already exists.");
			}
			String generatedOTP = EmailService.generateOtp();
			emailService.sendOtpEmail(seller.getEmail(), generatedOTP);
			session.setAttribute("seller", seller);
			session.setAttribute("email", seller.getEmail());
			session.setAttribute("generatedOTP", generatedOTP);
			// Service to save the seller
			return "seller_otp";
		}catch(EmailAlreadyExistsException e) {
			model.addAttribute("error",e.getMessage());
			return "seller_signup";
		}
		 // return success view after registration
	}

	@PostMapping("/verifyotpSignUp")
	public String verifyOtpSignUp(@RequestParam String enteredOtp,HttpSession session, Model model) {
		System.out.println(session.getAttribute("generatedOTP")+"otp");
		// Compare the OTP entered by the user with the generated OTP
		if (emailService.verifyOTP((String)session.getAttribute("email"), enteredOtp, (String)session.getAttribute("generatedOTP"))) {
			Seller seller = (Seller) session.getAttribute("seller");
			System.out.println(seller.getPasswordHash());
			sellerService.saveSeller((Seller) session.getAttribute("seller"));

			model.addAttribute("message", "Seller registered successfully!");

			return "redirect:/seller_welcome"; // Redirect to reset password page if OTP is correct
		} else {
			throw new InvalidOtpExceptionSeller("Invalid OTP. Please try again."); // Stay on OTP verification page
		}
	}


	
	@GetMapping("/seller_signin")
	public String seller_login() {
		return "seller_signin";
	}
	
	@PostMapping("/seller_signin")
    public String login(@RequestParam String email, @RequestParam String passwordHash, HttpSession session, Model model) {

        // Check if the user exists with the given email and password

        Seller seller = sellerService.findByEmail(email);
        session.setAttribute("seller", seller);
        // Validate the user's credentials
        if (seller != null && PasswordUtil.verifyPassword(passwordHash, seller.getPasswordHash())) {
            // If credentials are correct, redirect to the welcome page
        	session.setAttribute("seller", seller);
            return "redirect:/seller_welcome"; // Redirect to the welcome page
        } else {
            // If credentials are incorrect, add an error message and stay on the login page
            model.addAttribute("error", "Invalid email or password");
            return "seller_signin"; // Stay on the login page
        }
    }
	
//	@PostMapping("/seller_signin")
//	public String login(@RequestParam String email, @RequestParam String password, HttpSession session, Model model) {
//
//	    // Check if the seller exists with the given email
//	    Seller seller = sellerService.findByEmail(email);
//	    
//	    if (seller == null) {
//	        throw new SellerNotFoundException("Seller not found with the provided email.");
//	    }
//
//	    // Validate the user's credentials: throw PasswordMismatchException if password is incorrect
//	    if (!PasswordUtil.verifyPassword(password, seller.getPasswordHash())) {
//	        throw new PasswordMismatchExceptionSeller("Incorrect password.");
//	    }
//
//	    // If credentials are correct, set session attributes and redirect to the welcome page
//	    session.setAttribute("seller", seller);
//	    session.setAttribute("sellerId", seller.getSellerId());
//	    session.setAttribute("sellerName", seller.getFullName());
//	    
//	    return "redirect:/seller_welcome";
//	}

	@GetMapping("/seller_forgot_password")
	public String seller_forgot_pass() {
		return "seller_forgot_password";
	}
	
	@PostMapping("/forgotpassword")
    public String forgotPassword(@RequestParam String email,HttpSession session, Model model) {
		
        Seller seller = sellerService.findByEmail(email); // Check if the user exists
        session.setAttribute("email", seller.getEmail());
        if (seller != null) {
        	String generatedOTP = EmailService.generateOtp();// Generate OTP
            emailService.sendOtpEmail(email, generatedOTP); // Send the OTP to the user's email
            
            model.addAttribute("email", email); // Pass email to the OTP verification page
            model.addAttribute("generatedOTP", generatedOTP); // Store OTP in the model temporarily (or use session)
            return "seller_verify_otp"; // Redirect to OTP verification page
        } else {
            model.addAttribute("error", "Email not found"); // Error if email is not found
            return "seller_forgot_password"; // Stay on forgot password page
        }
    }
	
	@PostMapping("/verifyotp")
    public String verifyOtp(@RequestParam String email, @RequestParam String generatedOTP, @RequestParam String enteredOtp, Model model) {
        // Compare the OTP entered by the user with the generated OTP
        if (generatedOTP.equals(enteredOtp)) {
            return "seller_reset_password"; // Redirect to reset password page if OTP is correct
        } else {
            model.addAttribute("error", "Invalid OTP"); // Error if OTP is incorrect
            return "seller_verify_otp"; // Stay on OTP verification page
        }
    }

	@PostMapping("/resetpassword")
    public String resetPassword(HttpSession session, @RequestParam String passwordHash, @RequestParam String confirmPassword, Model model) {
        // Check if passwords match
		String email = (String)session.getAttribute("email");
        if (!passwordHash.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match"); // Error if passwords do not match
            return "seller_reset_password"; // Stay on reset password page
        }
        

        Seller seller = sellerService.findByEmail(email); // Fetch the user by email
        System.out.println(email + "seller");
        if (seller != null) {
            seller.setPasswordHash(passwordHash); // Set new password
            sellerService.saveSeller(seller); // Save the updated user in the database
            return "redirect:/seller_welcome"; // Redirect to login page after resetting password
        } else {
            model.addAttribute("error", "User not found"); // Error if user not found
            return "seller_reset_password"; // Stay on reset password page
        }
    }
	
	@GetMapping("/seller_welcome")
    public String viewProducts(Model model, HttpSession session) {
		Seller seller = (Seller) session.getAttribute("seller");
        List<Product> products = productService.getProductsBySellerId(seller.getSellerId());
        model.addAttribute("products", products);
        session.setAttribute("sellerId", seller.getSellerId());
        return "seller_welcome";  // The JSP page name
    }
	
	@GetMapping("/seller_product_detail/{id}")
    public String viewProductDetailsSeller(@PathVariable("id") String productId, Model model, HttpSession session) {
    	System.out.println("prod detail");
        Product product = productRepository.getProductByProductId(Long.valueOf(productId));
        model.addAttribute("product", product);
        session.setAttribute("product", product);
        return "seller_product_detail"; // Return the name of the view
    }


}
