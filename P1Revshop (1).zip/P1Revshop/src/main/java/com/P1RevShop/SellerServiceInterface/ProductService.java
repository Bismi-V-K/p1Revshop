package com.P1RevShop.SellerServiceInterface;


import com.P1RevShop.Entity.Product;

	

import java.util.List;


public interface ProductService {
	
	public List<Product> getProductsBySellerId(Long sellerId) ;
	void saveProduct(Product product);
	public List<Product> getallProducts();
	
	public List<Product> getProductsByCategoryId(Long category_id);
	public Product findProductById(Long productId);
	boolean deleteProductById(Long productId);
}
