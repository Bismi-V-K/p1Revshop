package com.P1RevShop.SellerServiceInterface;

import com.P1RevShop.Entity.Seller;

public interface SellerService {

	void saveSeller(Seller seller);

	Seller findByEmail(String email);

}
