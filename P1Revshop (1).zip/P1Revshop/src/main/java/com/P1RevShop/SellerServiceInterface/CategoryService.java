package com.P1RevShop.SellerServiceInterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.P1RevShop.Entity.Category;

public interface CategoryService {

	public List<Category> getAllCategory();
	
	Category getCategoryById(Long id); 
}
