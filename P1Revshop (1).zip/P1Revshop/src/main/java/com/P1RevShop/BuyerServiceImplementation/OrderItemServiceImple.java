package com.P1RevShop.BuyerServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.BuyerServiceInterface.OrderItemServiceInterface;
import com.P1RevShop.Entity.Order;
import com.P1RevShop.Entity.OrderItem;
import com.P1RevShop.Entity.Seller;
import com.P1RevShop.Repository.OrderItemRepository;
import com.P1RevShop.Repository.OrderRepository;

@Service
public class OrderItemServiceImple implements OrderItemServiceInterface{
	
	@Autowired
	private OrderItemRepository orderItemRepository;

	public List<OrderItem> findByOrder(Order order) {
        return orderItemRepository.findByOrder(order);
    }

	@Override
	public List<OrderItem> findBySeller(Seller seller) {
		return orderItemRepository.findBySeller(seller);
	}
	
}
