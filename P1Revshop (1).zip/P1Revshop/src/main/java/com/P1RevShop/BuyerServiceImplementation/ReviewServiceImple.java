package com.P1RevShop.BuyerServiceImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.BuyerServiceInterface.ReviewServiceInterface;
import com.P1RevShop.Entity.Reviews;
import com.P1RevShop.Repository.ReviewsRepository;

@Service
public class ReviewServiceImple implements ReviewServiceInterface {

    @Autowired
    private ReviewsRepository reviewsRepository;

    @Override
    public void saveReview(Reviews review) {
        reviewsRepository.save(review);
    }
}
