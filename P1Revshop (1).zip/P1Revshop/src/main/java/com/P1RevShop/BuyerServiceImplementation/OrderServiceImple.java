package com.P1RevShop.BuyerServiceImplementation;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.BuyerServiceInterface.OrderServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Order;
import com.P1RevShop.Entity.OrderItem;
import com.P1RevShop.Repository.OrderItemRepository;
import com.P1RevShop.Repository.OrderRepository;
import com.P1RevShop.Repository.ProductRepository;
import com.P1RevShop.Utility.EmailService;

import jakarta.mail.internet.ParseException;

@Service
public class OrderServiceImple implements OrderServiceInterface{
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private OrderItemRepository orderItemRepository;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public void saveOrders(Order order) {
		orderRepository.save(order);
	}
	
	 @Override
	    public void saveOrderItems(Order order, List<Cart> cartItems) {
	        for (Cart cart : cartItems) {
	        	 
	            OrderItem orderItem = new OrderItem();
	            
	            
	            orderItem.setOrder(order);
	            BigDecimal mrp = cart.getProduct().getMrp(); // Assuming this returns a BigDecimal
	            BigDecimal discount = BigDecimal.valueOf(cart.getProduct().getDiscountPrice().doubleValue()); // Convert double to BigDecimal

	            // (MRP * discount) / 100
	            BigDecimal discountAmount = mrp.multiply(discount).divide(BigDecimal.valueOf(100));

	            // Do further operations with BigDecimal as needed
	            orderItem.setPrice(discountAmount.doubleValue());
	            orderItem.setProduct(cart.getProduct());
	            orderItem.setQuantity(cart.getQuantity());
	            orderItem.setSeller(cart.getProduct().getSeller());
	            orderItemRepository.save(orderItem);
	            System.out.println(cart.getProduct().getNoOfItemsAvailable() + " noofproduct");

	         // Check stock level and send email if below threshold
	            if (cart.getProduct().getNoOfItemsAvailable() < 3) {
	                String to = cart.getProduct().getSeller().getEmail();
	                String sellerName = cart.getProduct().getSeller().getFullName();
	                Long productId = cart.getProduct().getProductId();
	                
	                String message = "Dear " + sellerName + ", as a seller in RevShop, your product with ID (" + productId + ") has reached the threshold stock level. Please restock soon to avoid running out.";
	                String subject = "Action Required: Product ID " + productId + " Has Reached Threshold Stock Level";

	                System.out.println("Sending email to: " + to); // Logging for debugging

	                try {
	                    emailService.sendEmail(to, message, subject);
	                    System.out.println("Email sent successfully to " + to);
	                } catch (Exception e) {
	                    System.err.println("Error sending email: " + e.getMessage());
	                    e.printStackTrace();
	                }
	            }
	            
	            productRepository.decrementNoOfItemsAvailable(cart.getProduct().getProductId(), cart.getQuantity());
	            productRepository.flush(); 
	            
	        }
    }


	@Override
	public List<Order> getOrdersByBuyerId(Long buyerId) {
		return orderRepository.findByBuyer_BuyerId(buyerId);
	}

	@Override
    public Order findById(Long orderId) {
        return orderRepository.findById(orderId).orElse(null); // or throw an exception if not found
    }


//	@Override
//	public List<Order> getOrdersBySellerId(Long sellerId) {
//		return orderRepository.findBySeller_SellerId(sellerId);
//	}

//	@Override
//	public List<Order> getOrdersByBuyerId(Buyer buyerId) {
//		return orderRepository.findByBuyer_BuyerId(buyerId);
//	}

//	@Override
//	public List<OrderItem> getOrderItemsByOrderId(Order orderId) {
//		return OrderRepository.order_orderId(orderId);
//	}

	
}
