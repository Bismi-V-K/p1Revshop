package com.P1RevShop.BuyerServiceImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.BuyerServiceInterface.BuyerService;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Repository.BuyerRepository;
import com.P1RevShop.Repository.SellerRepository;
import com.P1RevShop.Utility.PasswordUtil;



@Service
public class BuyerServiceImple implements BuyerService{

	@Autowired
	private BuyerRepository buyerRepository;
	
	@Override
	public Buyer findByBuyerEmail(String email) {
	    Buyer buyer = buyerRepository.findByBuyerEmail(email);
	    if (buyer == null) {
	        System.out.println("No buyer found with email: " + email);
	    } else {
	        System.out.println("Buyer found: " + buyer.getBuyerEmail());
	    }
	    return buyer;
	}


	@Override
	public void saveBuyer(Buyer buyer) {
//		String plainPassword = buyer.getPasswordHash();
//		buyer.setPasswordHash(PasswordUtil.hashPassword(plainPassword));
		buyerRepository.save(buyer);
	}


	@Override
	public Buyer findByBuyerId(Long buyerId){
        return buyerRepository.findByBuyerId(buyerId);
    }
}
