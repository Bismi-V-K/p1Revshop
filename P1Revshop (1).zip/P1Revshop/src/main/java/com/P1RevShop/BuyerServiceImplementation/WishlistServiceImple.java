package com.P1RevShop.BuyerServiceImplementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.BuyerServiceInterface.WishlistServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Wishlist;
import com.P1RevShop.Repository.CartRepository;
import com.P1RevShop.Repository.WishlistRepository;

import jakarta.transaction.Transactional;
@Service
public class WishlistServiceImple implements WishlistServiceInterface {
    @Autowired
    private WishlistRepository wishlistRepository;
    
    @Autowired
    private CartRepository cartRepository;

    @Override
    public void addToWishlist(Buyer buyer, Product product) {
        Wishlist wishlist = new Wishlist();
        wishlist.setBuyer(buyer);
        wishlist.setProduct(product);
        wishlistRepository.save(wishlist);
    }

    @Override
    public boolean isProductInWishlist(Buyer buyer, Product product) {
        return wishlistRepository.existsByBuyerAndProduct(buyer, product);
    }

    @Override
    public List<Wishlist> getWishlistItems(Buyer buyer) {
        return wishlistRepository.findByBuyer(buyer);
    }
    @Override
    public void removeFromWishlist(Wishlist wishlistItem) {
        wishlistRepository.delete(wishlistItem); // Make sure you have a WishlistRepository for this
    }

    
    @Override
    public void moveToCart(Wishlist wishlistItem, Buyer buyer) {
        // Create a new Cart item
    	Cart cartItem = new Cart();
        cartItem.setProduct(wishlistItem.getProduct());
        cartItem.setBuyer(buyer);
        cartItem.setQuantity(1); // Set the default quantity to 1

        // Save the cart item to the database
        cartRepository.save(cartItem);
    }
    
    @Override
    public Wishlist getWishlistById(Long wishlistId) {
        return wishlistRepository.findById(wishlistId).orElse(null);
    }
}

