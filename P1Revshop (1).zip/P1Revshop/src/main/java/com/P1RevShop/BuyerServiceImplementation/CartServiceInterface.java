package com.P1RevShop.BuyerServiceImplementation;

import java.util.List;

import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Product;

public interface CartServiceInterface {


	public List<Cart> getCartItemsByBuyer(Buyer buyer);
	public void addToCart(Cart cart) ;
	boolean deleteCartItemsByProductId(Long productId);
	public void clearCart(Buyer buyer);
}
