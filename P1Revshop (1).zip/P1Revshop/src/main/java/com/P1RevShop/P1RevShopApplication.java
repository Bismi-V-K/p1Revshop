package com.P1RevShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication(scanBasePackages = "com.P1RevShop")
@EnableAspectJAutoProxy
public class P1RevShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(P1RevShopApplication.class, args);
	}

}
