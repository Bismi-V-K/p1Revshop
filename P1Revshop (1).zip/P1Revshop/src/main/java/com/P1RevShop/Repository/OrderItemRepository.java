package com.P1RevShop.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.P1RevShop.Entity.Order;
import com.P1RevShop.Entity.OrderItem;
import com.P1RevShop.Entity.Seller;

@Repository
public interface OrderItemRepository extends JpaRepository<OrderItem, Long>{

	List<OrderItem> findByOrder(Order order);

	List<OrderItem> findBySeller(Seller seller);

}
