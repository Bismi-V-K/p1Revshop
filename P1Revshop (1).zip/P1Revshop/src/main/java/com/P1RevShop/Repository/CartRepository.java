package com.P1RevShop.Repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Product;

import jakarta.transaction.Transactional;

import java.util.List;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {

	@Modifying
    @Query("SELECT c FROM Cart c JOIN FETCH c.product WHERE c.buyer = :buyer")
	@Transactional
    List<Cart> findCartByBuyer(@Param("buyer") Buyer buyer);

    List<Cart> findByProduct_ProductId(Long productId);

	void deleteByBuyer(Buyer buyer);
}


