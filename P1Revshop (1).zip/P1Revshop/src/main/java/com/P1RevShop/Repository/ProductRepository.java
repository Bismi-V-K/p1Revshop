package com.P1RevShop.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.P1RevShop.Entity.Product;

import jakarta.transaction.Transactional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	
	// Custom method to find products by seller_id
    List<Product> findBySeller_SellerId(Long sellerId);
    
    List<Product> findByCategory_CategoryId(Long category_id); // New method to fetch products by category ID
    
    @Modifying
    @Transactional
    @Query("UPDATE Product p SET p.noOfItemsAvailable = p.noOfItemsAvailable - :quantity WHERE p.productId = :productId")
    void decrementNoOfItemsAvailable(@Param("productId") Long productId, @Param("quantity") int quantity);
    
    Product getProductByProductId(Long valueOf);
}

