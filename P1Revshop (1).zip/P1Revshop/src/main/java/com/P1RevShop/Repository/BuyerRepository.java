package com.P1RevShop.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.P1RevShop.Entity.Buyer;

@Repository
public interface BuyerRepository extends JpaRepository<Buyer, Long> {
    Buyer findByBuyerEmail(String buyerEmail);
    
    Buyer findByBuyerId(Long buyerId);
}

