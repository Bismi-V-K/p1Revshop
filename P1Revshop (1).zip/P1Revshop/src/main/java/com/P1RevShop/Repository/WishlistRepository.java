package com.P1RevShop.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Wishlist;

@Repository
public interface WishlistRepository extends JpaRepository<Wishlist, Long> {
	List<Wishlist> findByBuyer(Buyer buyer);
    boolean existsByBuyerAndProduct(Buyer buyer, Product product);
}
