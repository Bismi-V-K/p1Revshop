package com.P1RevShop.BuyerServiceInterface;

import java.util.List;

import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Entity.Wishlist;

public interface WishlistServiceInterface {

	void addToWishlist(Buyer buyer, Product product);
    boolean isProductInWishlist(Buyer buyer, Product product);
    List<Wishlist> getWishlistItems(Buyer buyer);
    public Wishlist getWishlistById(Long wishlistId);
    public void moveToCart(Wishlist wishlistItem, Buyer buyer);;
    public void removeFromWishlist(Wishlist wishlistItem);
    
}
