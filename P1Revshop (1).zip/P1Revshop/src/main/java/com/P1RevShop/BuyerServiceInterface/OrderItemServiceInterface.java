package com.P1RevShop.BuyerServiceInterface;

import java.util.List;

import com.P1RevShop.Entity.Order;
import com.P1RevShop.Entity.OrderItem;
import com.P1RevShop.Entity.Seller;

public interface OrderItemServiceInterface {

	public List<OrderItem> findByOrder(Order order);
	
	public List<OrderItem> findBySeller(Seller sellerId);
	
}
