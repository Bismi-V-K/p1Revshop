package com.P1RevShop.BuyerServiceInterface;

import com.P1RevShop.Entity.Reviews;

public interface ReviewServiceInterface {

	void saveReview(Reviews review);
	
}
