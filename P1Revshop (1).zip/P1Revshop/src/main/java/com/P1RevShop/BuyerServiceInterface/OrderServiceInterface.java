package com.P1RevShop.BuyerServiceInterface;

import java.util.List;

import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Order;
import com.P1RevShop.Entity.OrderItem;

import jakarta.mail.internet.ParseException;

public interface OrderServiceInterface {

	public List<Order> getOrdersByBuyerId(Long buyerId);
	public void saveOrders(Order order) ;
	public void saveOrderItems(Order order, List<Cart> cartItems) ;
	//public List<OrderItem> getOrderItemsByOrderId(Order orderId);
	//public List<Order> getOrdersBySellerId(Long sellerId);
	Order findById(Long orderId);
	
	
}
