package com.P1RevShop.BuyerServiceInterface;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.P1RevShop.BuyerServiceImplementation.CartServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Repository.CartRepository;

import jakarta.transaction.Transactional;

@Service
public class CartServiceImple implements CartServiceInterface {

    @Autowired
    private CartRepository cartRepository;

    public List<Cart> getCartItemsByBuyer(Buyer buyer) {
        return cartRepository.findCartByBuyer(buyer);
    }
    
    public void addToCart(Cart cart) {
    	cartRepository.save(cart);
    }
    
    @Override
    public boolean deleteCartItemsByProductId(Long productId) {
        List<Cart> carts = cartRepository.findByProduct_ProductId(productId);
        
        if (carts != null && !carts.isEmpty()) {
            cartRepository.deleteAll(carts);
            return true; // Successfully deleted from the cart
        }
        return false; // No items found to delete
    }
    
    @Override
    @Transactional
    public void clearCart(Buyer buyer) {
    	cartRepository.deleteByBuyer(buyer);
    }
}