package com.P1RevShop.BuyerServiceInterface;

import com.P1RevShop.Entity.Buyer;

public interface BuyerService {

	void saveBuyer(Buyer buyer);

	Buyer findByBuyerEmail(String buyerEmail);
	
	public Buyer findByBuyerId(Long buyerId);
	
}
