package com.P1RevShop.Exceptions;

public class InvalidOtpExceptionSeller extends RuntimeException {

    public InvalidOtpExceptionSeller(String message) {
        super(message);
    }
}
