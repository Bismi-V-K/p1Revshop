package com.P1RevShop.Exceptions;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(InvalidOtpExceptionSeller.class)
    public String handleInvalidOtpException(InvalidOtpException ex, Model model) {
        model.addAttribute("error", ex.getMessage()); // Set the error message in the model
        return "seller_otp"; // Return to the OTP verification page
    }
    
    @ExceptionHandler(InvalidOtpException.class)
    public String handleInvalidOtpExceptionSeller(InvalidOtpException ex, Model model) {
        model.addAttribute("error", ex.getMessage()); // Set the error message in the model
        return "buyer_otp"; // Return to the OTP verification page
    }
    
    @ExceptionHandler(BuyerNotFoundException.class)
    public String handleBuyerNotFoundException(BuyerNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "buyer_signin"; // Redirect to the login page
    }
    
    @ExceptionHandler(SellerNotFoundException.class)
    public String handleSellerNotFoundException(SellerNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "seller_signin"; // Redirect to the login page
    }
    
    @ExceptionHandler(PasswordMismatchException.class)
    public String handlePasswordMismatchException(PasswordMismatchException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "buyer_signin"; // Redirect to the login page with error
    }
    
    @ExceptionHandler(PasswordMismatchExceptionSeller.class)
    public String handlePasswordMismatchExceptionSeller(PasswordMismatchException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "seller_signin"; // Redirect to the login page with error
    }
    
    @ExceptionHandler(InsufficientItemsException.class)
    public String handleInsufficientItemsException(InsufficientItemsException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "buyer_welcome";  // Display error page with the message
    }
    
    
}