package com.P1RevShop.Exceptions;
public class InsufficientItemsException extends RuntimeException {

    public InsufficientItemsException(String message) {
        super(message);
    }

    public InsufficientItemsException(String message, Throwable cause) {
        super(message, cause);
    }
}