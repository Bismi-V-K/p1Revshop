package com.P1RevShop.Exceptions;

public class PasswordMismatchExceptionSeller extends RuntimeException {
    public PasswordMismatchExceptionSeller(String message) {
        super(message);
    }
}
