package com.P1RevShop.CartControllerTesing;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.P1RevShop.BuyerController.CartController;
import com.P1RevShop.BuyerServiceImplementation.CartServiceInterface;
import com.P1RevShop.Entity.Buyer;
import com.P1RevShop.Entity.Cart;
import com.P1RevShop.Entity.Product;
import com.P1RevShop.Exceptions.InsufficientItemsException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;

import jakarta.servlet.http.HttpSession;

class CartControllerTest {

    @InjectMocks
    private CartController cartController; // Assuming the controller class is named CartController

    @Mock
    private CartServiceInterface cartService;

    @Mock
    private HttpSession session;

    @Mock
    private Model model;

    private Buyer mockBuyer;
    private Product mockProduct;
    private Cart mockCart;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockBuyer = new Buyer();
        mockBuyer.setBuyerId(1L); // assuming an id setter
        mockProduct = new Product();
        mockProduct.setProductId(1L); // assuming a product id setter
        mockProduct.setProdName("Test Product");
        mockCart = new Cart();
        mockCart.setBuyer(mockBuyer);
        mockCart.setProduct(mockProduct);
    }

    @Test
    void testAddToCart_SuccessfulAddition() {
        // Arrange
        mockProduct.setNoOfItemsAvailable(10);
        when(session.getAttribute("buyer")).thenReturn(mockBuyer);
        when(session.getAttribute("product")).thenReturn(mockProduct);
        
        // Act
        String result = cartController.addToCart("2", model, session);

        // Assert
        assertEquals("redirect:/product_details_after_login/" + mockProduct.getProductId(), result);
        verify(cartService, times(1)).addToCart(any(Cart.class));
    }

    @Test
    void testAddToCart_InsufficientItemsException() {
        // Arrange
        mockProduct.setNoOfItemsAvailable(0);
        when(session.getAttribute("buyer")).thenReturn(mockBuyer);
        when(session.getAttribute("product")).thenReturn(mockProduct);

        // Act & Assert
        assertThrows(InsufficientItemsException.class, () -> {
            cartController.addToCart("2", model, session);
        });
        verify(cartService, never()).addToCart(any(Cart.class));
    }

    @Test
    void testAddToCart_InvalidQuantityException() {
        // Arrange
        mockProduct.setNoOfItemsAvailable(10);
        when(session.getAttribute("buyer")).thenReturn(mockBuyer);
        when(session.getAttribute("product")).thenReturn(mockProduct);

        // Act & Assert
        assertThrows(NumberFormatException.class, () -> {
            cartController.addToCart("invalidQuantity", model, session);
        });
        verify(cartService, never()).addToCart(any(Cart.class));
    }
}
